python3 setup.py sdist
python3 -m twine upload dist/cryptocom-0.3.1.tar.gz